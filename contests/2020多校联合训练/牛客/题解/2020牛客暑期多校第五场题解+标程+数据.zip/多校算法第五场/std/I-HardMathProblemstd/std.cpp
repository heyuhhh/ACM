#include <bits/stdc++.h>

int main() {
    puts("0.666667");
    return 0;
}